# Lucy VTON Backend

Backend mínimo em Node.js + TypeScript para gerar um token temporário para o
`decart/lucy2-vton/realtime` da fal.ai.

O vídeo/WebRTC não passa por este servidor. O browser usa o token retornado
por este endpoint para estabelecer a sessão realtime com a fal.ai.

## Requisitos

- Node.js 20+
- Uma API key da fal.ai

## Instalação

```bash
npm install
cp .env.example .env
```

Edite `.env`:

```env
FAL_KEY=...
PORT=3000
# Origens do frontend, separadas por vírgula
ALLOWED_ORIGIN=http://localhost:8080
# Apps para os quais o endpoint emite token (padrão: decart/lucy2-vton/realtime)
ALLOWED_REALTIME_APPS=decart/lucy2-vton/realtime
# Limite de tokens por IP por minuto (padrão: 10)
TOKEN_RATE_LIMIT_PER_MINUTE=10
# Defina como 1 atrás de um proxy reverso, para o rate limit usar o IP real
TRUST_PROXY=
```

No frontend (`cheerful-pal-advisor`), aponte para este backend com
`VITE_LUCY_BACKEND_URL`. O padrão é a produção
(`https://provador-virtual-psi.vercel.app`); em dev local use
`VITE_LUCY_BACKEND_URL=http://localhost:3000`.

## Desenvolvimento

```bash
npm run dev
```

## Endpoint

### POST /api/fal/realtime-token

Request:

```json
{
  "app": "decart/lucy2-vton/realtime"
}
```

O `app` é o id do modelo, que o `fal.realtime.connect` passa para o
`tokenProvider`. Ele define para qual modelo o token vale: um nome qualquer
(ex.: o nome do site) gera um token que a fal.ai recusa para o Lucy.

Response (`text/plain`, apenas o JWT, válido por 120s):

```
eyJhbGciOi...
```

Erros: `403` para um `app` fora de `ALLOWED_REALTIME_APPS`, `429` ao passar
do rate limit e `502` se a fal.ai recusar a criação do token (ex.: `FAL_KEY`
inválida).

O token é escopado ao app pedido e só é usado para abrir o WebSocket de
sinalização. O Lucy é cobrado por segundo de sessão, então o frontend só
conecta quando o usuário toca em "Começar" e encerra a sessão em 30s.

O frontend deve usar esse token como `tokenProvider` ao conectar ao modelo
realtime da fal.ai. O WebSocket só carrega a sinalização WebRTC (offer/answer/ICE)
e os controles (prompt, roupa); a câmera precisa ser enviada por uma
`RTCPeerConnection` — veja `src/lib/lucy-vton.ts` no frontend.

Exemplo conceitual:

```ts
const connection = fal.realtime.connect(
  "decart/lucy2-vton/realtime",
  {
    tokenProvider: async (app) => {
      const response = await fetch(
        "https://provador-virtual-psi.vercel.app/api/fal/realtime-token",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ app })
        }
      );

      return response.text();
    }
  }
);
```

## Segurança

Nunca coloque `FAL_KEY` no frontend.

O endpoint já só aceita os apps de `ALLOWED_REALTIME_APPS` e aplica um rate
limit em memória por IP. Para produção com várias instâncias, troque o rate
limit por um store compartilhado (ex.: Redis) e considere autenticar o
endpoint.
