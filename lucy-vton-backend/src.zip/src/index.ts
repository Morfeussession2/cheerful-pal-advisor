import "dotenv/config";
import express from "express";
import cors from "cors";

const app = express();
const port = Number(process.env.PORT ?? 3000);

const FAL_KEY = process.env.FAL_KEY;

// Sem a chave o servidor sobe mesmo assim: /health e as rotas explicam o
// problema, em vez de a função inteira falhar (FUNCTION_INVOCATION_FAILED na Vercel).
if (!FAL_KEY) {
  console.error("FAL_KEY não configurada");
}

const FAL_REST_URL = "https://rest.fal.ai";
const TOKEN_EXPIRATION_SECONDS = 120;

// Apps que o frontend pode pedir token. Evita que o endpoint vire um emissor
// de tokens para qualquer modelo da fal.ai pago com a nossa FAL_KEY.
const ALLOWED_REALTIME_APPS = (
  process.env.ALLOWED_REALTIME_APPS ?? "decart/lucy2-vton/realtime"
)
  .split(",")
  .map((value) => value.trim())
  .filter(Boolean);

const allowedOrigins = (process.env.ALLOWED_ORIGIN ?? "*")
  .split(",")
  .map((value) => value.trim())
  .filter(Boolean);

// Atrás de um proxy reverso (Render, Railway, Nginx...) defina TRUST_PROXY=1
// para que req.ip seja o IP real do cliente no rate limit.
const trustProxy = process.env.TRUST_PROXY;
if (trustProxy) {
  app.set("trust proxy", /^\d+$/.test(trustProxy) ? Number(trustProxy) : trustProxy);
}

app.use(express.json({ limit: "1mb" }));

app.use(
  cors({
    origin: allowedOrigins.includes("*") ? "*" : allowedOrigins,
  }),
);

// Rate limit em memória por IP para o emissor de tokens. Suficiente para uma
// instância única; com várias instâncias, troque por um store compartilhado.
const TOKEN_RATE_LIMIT = Number(process.env.TOKEN_RATE_LIMIT_PER_MINUTE ?? 10);
const tokenRequests = new Map<string, number[]>();

function isRateLimited(ip: string) {
  const now = Date.now();
  const recent = (tokenRequests.get(ip) ?? []).filter(
    (timestamp) => now - timestamp < 60_000,
  );
  recent.push(now);
  tokenRequests.set(ip, recent);
  return recent.length > TOKEN_RATE_LIMIT;
}

app.post("/api/fal/realtime-token", async (req, res) => {
  if (!FAL_KEY) {
    return res.status(500).json({ error: "FAL_KEY não configurada no servidor" });
  }

  const requestedApp = typeof req.body?.app === "string" ? req.body.app : "";

  if (!ALLOWED_REALTIME_APPS.includes(requestedApp)) {
    return res.status(403).json({ error: "App not allowed" });
  }

  if (isRateLimited(req.ip ?? "unknown")) {
    return res.status(429).json({ error: "Too many requests" });
  }

  // "decart/lucy2-vton/realtime" -> alias "lucy2-vton"
  const [, alias] = requestedApp.split("/");

  try {
    const response = await fetch(`${FAL_REST_URL}/tokens/`, {
      method: "POST",
      headers: {
        Authorization: `Key ${FAL_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        allowed_apps: [alias],
        token_expiration: TOKEN_EXPIRATION_SECONDS,
      }),
    });

    if (!response.ok) {
      console.error(
        "fal token request failed",
        response.status,
        await response.text(),
      );
      return res.status(502).json({ error: "Failed to create fal token" });
    }

    const body: unknown = await response.json();
    const token =
      typeof body === "string"
        ? body
        : (body as { detail?: string; token?: string }).detail ??
          (body as { token?: string }).token;

    if (!token) {
      return res.status(502).json({ error: "Unexpected fal token response" });
    }

    // Contrato do endpoint: apenas o JWT, como texto puro.
    return res.type("text/plain").send(token);
  } catch (error) {
    console.error("fal token request error", error);
    return res.status(502).json({ error: "Failed to create fal token" });
  }
});

app.all("/api/fal/proxy", async (req, res) => {
  if (!["GET", "POST"].includes(req.method)) {
    return res.status(405).send("Method Not Allowed");
  }

  if (!FAL_KEY) {
    return res.status(500).send("FAL_KEY não configurada no servidor");
  }

  const targetUrl = req.header("x-fal-target-url");

  if (!targetUrl) {
    return res.status(400).send("Missing x-fal-target-url");
  }

  const url = new URL(targetUrl);

  if (
    !url.hostname.endsWith(".fal.ai") &&
    !url.hostname.endsWith(".fal.run")
  ) {
    return res.status(412).send("Invalid fal target");
  }

  const response = await fetch(url, {
    method: req.method,
    headers: {
      Authorization: `Key ${FAL_KEY}`,
      "Content-Type": "application/json",
    },
    body: req.method === "POST" ? JSON.stringify(req.body) : undefined,
  });

  const body = await response.text();

  res.status(response.status);

  const contentType = response.headers.get("content-type");
  if (contentType) {
    res.setHeader("content-type", contentType);
  }

  return res.send(body);
});

app.get("/health", (_req, res) => {
  res.json({ ok: true, falKeyConfigured: Boolean(FAL_KEY) });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
